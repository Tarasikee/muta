# Muta (The diabetes prediction/observation tool)

Muta is a tool that helps in predicting the possibility of a person having diabetes.

